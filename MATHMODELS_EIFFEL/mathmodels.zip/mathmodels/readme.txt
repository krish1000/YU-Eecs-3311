

Mathmodels includes collections such as
	SET[G]
	FUN[G,H]
	REL[G,H]
	BAG[G]
	SEQ[G]

The above collections are executable but also have strong queries
for contracts. These collections are thus helpful for high-level
specifications and models.

It also contains
	VALUE -- arbitrary precision arithmetic for +, - and *
	FLOAT -- like REAL_64 but with epsilon